close all;
clc;
clear;

L=20;  %mm
W=20;  %mm
meshsize=0.1; %mm

load mesh3000.dat;
mesh=mesh3000;
for i=1:size(mesh,1)
    x=floor((i-1)/(W/meshsize+1))+1;
    y=i-(x-1)*(W/meshsize+1);
    if x>1
    m(y,x-1)=mesh(i,1);
    if mesh(i,1)==0 
        m(y,x-1)=NaN;
    end;
    v(y,x-1)=mesh(i,3);
    end;

end

figure(1)
surf((meshsize:meshsize:L),(0:meshsize:W),m);
shading interp;
colormap jet;

figure(2)
surf((meshsize:meshsize:L),(0:meshsize:W),v);
shading interp;
colormap jet;
axis equal;
set(gca,'visible','off');
view(2);

