close all;
clc;
clear;


contne=1;   % whether a new run (0) or continue (1)

%%%%%%%%%%%%% Initialize Position %%%%%%%%%%%%%%%%%%%

  global  Fn dt dV vstdgas;
 
  Boltzman=1.3806505e-23;        %J/K
  Temperature=273.15;               %K
  m=28;                    % molecular weight of N2 amu
  mass=m.*1.660539040*10^-27;     % kg
  L=20; %mm full length
  W=20; %mm width of chamber
  Wl=0.6; %mm width of inlet
  meshsize=0.1; %mm  
  partitionx=1; %mm length of inlet
  Fn=1*10^5;  % number of real particles represented by one simulated particle 
  mesh=zeros((L/meshsize+1)*(W/meshsize+1),3); % mesh(:,1)=number of particles in each cell, mesh(:,2)=sigmacr_max, mesh(:,3)=average axial velocity magnitude in each cell
  vdrift1=(1.251*0.001*1/mass)^(2/3);
  vstdgas=sqrt(Boltzman*Temperature/mass)/1000;   %mm/us
  vdrift=0.4;  %mm/us
  tstep=0.1; % us
  period=100;  % us
  dt=tstep;
  dV=meshsize^2;
  nstep=round(period/tstep); 
  ldn=500;
  
if contne==0
  ptcl=[];
  tinfo=0;  %time step
  tn=0; 
  for q=tn+1:tn+ldn             
      ptcl(q,2)=rand(1)*vdrift*tstep; % mm         
      ptcl(q,3)=rand(1)*Wl-Wl/2;  % mm
      
      s=1;
      while  (s>=1) 
        u1=2*rand()-1;
        u2=2*rand()-1;
        s=u1^2+u2^2;
      end;
      g1=u1*sqrt(-2*log(s)/s);  %gaussian random generator
      ptcl(q,4)=g1*vstdgas+vdrift; %normrnd(0,vstdgas,[1 tn1+tn2]);
      
      s=1;
      while  (s>=1) 
        u1=2*rand()-1;
        u2=2*rand()-1;
        s=u1^2+u2^2;
      end;
      g2=u1*sqrt(-2*log(s)/s);  %gaussian random generator
      ptcl(q,5)=g2*vstdgas;        %normrnd(0,vstdgas,[1 tn1+tn2]);
      
      %%% indexing: attribute each particle to a cell
      ox=round((ptcl(q,2))/meshsize);
      oy=round((ptcl(q,3)+W/2)/meshsize);
      
      ptcl(q,1)=(ox)*(W/meshsize+1)+oy+1;
      pl=floor((ptcl(q,2))/meshsize);
      pr=pl+1;
      
     if ptcl(q,3)==(W/2) || (Wl/2)
       pd=floor((ptcl(q,3)-0.000001+W/2)/meshsize);
     else
       pd=floor((ptcl(q,3)+W/2)/meshsize);
     end;
     pu=pd+1;    
     
     mesh((pl*(W/meshsize+1)+pd+1),1)=mesh((pl*(W/meshsize+1)+pd+1),1)+(pr*meshsize-ptcl(q,2))*(pu*meshsize-(ptcl(q,3)+W/2))/(meshsize^2);
     mesh((pl*(W/meshsize+1)+pu+1),1)=mesh((pl*(W/meshsize+1)+pu+1),1)+(pr*meshsize-ptcl(q,2))*((ptcl(q,3)+W/2)-pd*meshsize)/(meshsize^2);
     mesh((pr*(W/meshsize+1)+pd+1),1)=mesh((pr*(W/meshsize+1)+pd+1),1)+(ptcl(q,2)-pl*meshsize)*(pu*meshsize-(ptcl(q,3)+W/2))/(meshsize^2);
     mesh((pr*(W/meshsize+1)+pu+1),1)=mesh((pr*(W/meshsize+1)+pu+1),1)+(ptcl(q,2)-pl*meshsize)*((ptcl(q,3)+W/2)-pd*meshsize)/(meshsize^2);
    
   end;
   tn=tn+ldn;

else
  load recordstep2000.dat;
  ptcl=recordstep2000;
  tinfo=2000;   %if continue=1, change to the last time step of the last run
  tn=size(ptcl,1);
  load mesh2000.dat;
  mesh=mesh2000;

end;

tic
for j=1:nstep
   
   tinfo=tinfo+1;     %timestep
   remove=[];
   removei=[];
    
%%%%%%%%%%%% Collision %%%%%%%%%%%%%%%%%%
  msize=size(mesh,1);
  for k=1:msize   
    index=find(ptcl(:,1)==k);
    if (size(index,1)>=2)
      group=ptcl(index,:);
      [ptcl(index,:), mesh(k,2)]=NTCcollision2(group,mesh(k,1),mesh(k,2));  % mesh(k,1)=number of particles in this cell, mesh(k,2)=sigmacr_max
    end;
    mesh(k,3)=mean(ptcl(index,4));  % mesh(k,3)=average axial velocity magnitude in this cell
  end;
  mesh(:,1)=0; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%% Move Ions and Remove Outbound Ions %%%%%%%%   
  for p=1:tn
      newx=ptcl(p,2)+ptcl(p,4)*tstep;  % mm
      newy=ptcl(p,3)+ptcl(p,5)*tstep;  % mm
      
      if (newx<0) || (newx>L)   
          remove(p)=1;
      else 
          remove(p)=0;
      end;
           
      if (ptcl(p,2)-partitionx)*(newx-partitionx)>=0   
        if newx<partitionx
          if (newy<-Wl/2) || (newy>Wl/2)
            ptcl(p,3)=newy/(abs(newy))*(Wl-abs(newy));
            ptcl(p,5)=-ptcl(p,5);
          else
            ptcl(p,3)=newy;
          end;
        else
          if (newy<-W/2) || (newy>W/2)
            ptcl(p,3)=newy/(abs(newy))*(W-abs(newy));
            ptcl(p,5)=-ptcl(p,5);
          else
            ptcl(p,3)=newy;
          end;
        end;
        ptcl(p,2)=newx;   
      else
        if (ptcl(p,4)<0) && (abs(newy)>Wl/2) 
          ptcl(p,2)=2*partitionx-newx;
          ptcl(p,4)=-ptcl(p,4);
          ptcl(p,3)=newy;
        else
          ptcl(p,2)=newx;
          ptcl(p,3)=newy;
        end;
      end;
   
  end;
  
  ri=1;
  for removeindex=1:size(remove,2);
     if remove(removeindex)==1;
       removei(ri)=removeindex;
       ri=ri+1;
     end;
  end;
  ptcl(removei,:)=[];
  remove=[];
  removei=[];
  ri=1;
  tn=size(ptcl,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   


%%%%%%%%%%%% Generate New Ions  %%%%%%%%%%%%%%
   for q=tn+1:tn+ldn             
      ptcl(q,2)=rand(1)*vdrift*tstep; % mm         
      ptcl(q,3)=rand(1)*Wl-Wl/2;  % mm

      s=1;
      while  (s>=1) 
        u1=2*rand()-1;
        u2=2*rand()-1;
        s=u1^2+u2^2;
      end;
      g1=u1*sqrt(-2*log(s)/s);  %gaussian random generator
      ptcl(q,4)=g1*vstdgas+vdrift; %normrnd(0,vstdgas,[1 tn1+tn2]);
      
      s=1;
      while  (s>=1) 
        u1=2*rand()-1;
        u2=2*rand()-1;
        s=u1^2+u2^2;
      end;
      g2=u1*sqrt(-2*log(s)/s);  %gaussian random generator
      ptcl(q,5)=g2*vstdgas;     %normrnd(0,vstdgas,[1 tn1+tn2]);
   end;
   tn=tn+ldn;

   for p=1:tn    % indexing: attribute each particle to a cell
     ox=round((ptcl(p,2))/meshsize);
     oy=round((ptcl(p,3)+W/2)/meshsize);
     ptcl(p,1)=(ox)*(W/meshsize+1)+oy+1;
     pl=floor((ptcl(p,2))/meshsize);
     pr=pl+1;
      
    if ptcl(p,3)==(W/2) || (Wl/2)
      pd=floor((ptcl(p,3)-0.000001+W/2)/meshsize);
    else
      pd=floor((ptcl(p,3)+W/2)/meshsize);
    end;
    pu=pd+1;    

    mesh((pl*(W/meshsize+1)+pd+1),1)=mesh((pl*(W/meshsize+1)+pd+1),1)+(pr*meshsize-ptcl(p,2))*(pu*meshsize-(ptcl(p,3)+W/2))/(meshsize^2);
    mesh((pl*(W/meshsize+1)+pu+1),1)=mesh((pl*(W/meshsize+1)+pu+1),1)+(pr*meshsize-ptcl(p,2))*((ptcl(p,3)+W/2)-pd*meshsize)/(meshsize^2);
    mesh((pr*(W/meshsize+1)+pd+1),1)=mesh((pr*(W/meshsize+1)+pd+1),1)+(ptcl(p,2)-pl*meshsize)*(pu*meshsize-(ptcl(p,3)+W/2))/(meshsize^2);
    mesh((pr*(W/meshsize+1)+pu+1),1)=mesh((pr*(W/meshsize+1)+pu+1),1)+(ptcl(p,2)-pl*meshsize)*((ptcl(p,3)+W/2)-pd*meshsize)/(meshsize^2);
  end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%% Record %%%%%%%%%%%%%%%%%

  if mod(j,100)==0
    fileID=fopen(['mesh' num2str(tinfo) '.dat'],'a');
    for pt=1:size(mesh,1)
     fprintf(fileID, '%12.8f\t', mesh(pt,:));
     fprintf(fileID, '\n');
    end;
    fclose(fileID);
    toc;
  end;

  if mod(j,500)==0
    fileID=fopen(['recordstep' num2str(tinfo) '.dat'],'a');
    for pt=1:size(ptcl,1)
      fprintf(fileID, '%12.8f\t', ptcl(pt,:));
      fprintf(fileID, '\n');
    end;
    fclose(fileID);
  end;

end;
